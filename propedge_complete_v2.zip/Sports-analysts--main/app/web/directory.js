const sportSel = document.getElementById('dir-sport');
const teamSel = document.getElementById('dir-team');
const searchInput = document.getElementById('dir-search');
const pageEl = document.getElementById('directory-page');

let groups = [];

function renderGroups() {
  const q = searchInput.value.trim().toLowerCase();
  const teamFilter = teamSel.value;
  const filtered = groups
    .filter(g => !teamFilter || g.team === teamFilter)
    .map(g => ({ ...g, players: g.players.filter(p => !q || p.name.toLowerCase().includes(q)) }))
    .filter(g => g.players.length || !teamFilter && !q);

  pageEl.innerHTML = filtered.map(g => `
    <section class="directory-section">
      <div class="directory-team-head"><h3>${g.team_name}</h3><span class="pill">${g.team}</span></div>
      <div class="directory-grid">
        ${g.players.length ? g.players.map(p => `<a class="directory-link" href="/research?player=${encodeURIComponent(p.name)}&sport=${encodeURIComponent(sportSel.value)}">${p.name}<span>${p.team}</span></a>`).join('') : '<div class="empty-state">No locally bundled players for this team yet</div>'}
      </div>
    </section>`).join('');
}

async function loadDirectory() {
  pageEl.innerHTML = `<div class="loading"><div class="spinner"></div><span class="loading-text">Loading directory...</span></div>`;
  const sport = sportSel.value;
  const [teamsRes, playersRes] = await Promise.all([
    fetch(`/api/teams?sport=${sport}`).then(r => r.json()),
    fetch(`/api/players?sport=${sport}&grouped=true`).then(r => r.json()),
  ]);
  teamSel.innerHTML = '<option value="">All Teams</option>' + teamsRes.teams.map(t => `<option value="${t.code}">${t.name}</option>`).join('');
  groups = playersRes.groups;
  renderGroups();
}

sportSel.addEventListener('change', loadDirectory);
teamSel.addEventListener('change', renderGroups);
searchInput.addEventListener('input', renderGroups);
loadDirectory();
