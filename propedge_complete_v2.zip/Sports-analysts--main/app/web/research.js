function fmtStat(s) { return s.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()); }
function pctClass(v) { return v >= 55 ? 'positive' : v >= 45 ? 'neutral' : 'negative'; }

const params = new URLSearchParams(window.location.search);
const player = params.get('player') || 'Luka Doncic';
const sport = params.get('sport') || 'nba';
const opp = params.get('opp') || '';
const market = params.get('market') || '';
const page = document.getElementById('research-page');

function marketButton(data, m) {
  const qs = new URLSearchParams({ player: data.player, sport: data.sport, opp: data.opponent, market: m });
  return `<a class="market-chip ${m === data.market ? 'active' : ''}" href="/research?${qs.toString()}">${fmtStat(m)}</a>`;
}

function recentBar(game, line) {
  const height = Math.max(24, Math.min(140, game.value * 5));
  return `<div class="mini-bar-wrap"><div class="mini-bar ${game.hit ? 'hit' : 'miss'}" style="height:${height}px"></div><div class="mini-bar-val">${game.value}</div><div class="mini-bar-label">${game.label}</div></div>`;
}

function renderNBA(data) {
  return `
  <section class="research-shell">
    <div class="research-hero">
      <div>
        <div class="eyebrow">${data.team} · ${data.team_name}</div>
        <h1>${data.player}</h1>
        <div class="hero-sub">${fmtStat(data.market)} vs ${data.opponent_name} · line ${data.line}</div>
      </div>
      <div class="hero-actions">${data.available_markets.map(m => marketButton(data, m)).join('')}</div>
    </div>

    <div class="research-grid top">
      <article class="research-card">
        <div class="kpi-row">
          <div><div class="kpi-label">Hit Rate</div><div class="kpi-big">${data.hit_rates.l10}%</div><div class="kpi-sub">L10 · Avg ${data.avg}</div></div>
          <div class="line-pill ${pctClass(data.sim.p_over)}">${data.sim.p_over}% over</div>
        </div>
        <div class="hit-tabs">
          <span>L5 ${data.hit_rates.l5}%</span><span>L10 ${data.hit_rates.l10}%</span><span>L20 ${data.hit_rates.l20}%</span><span>H2H ${data.hit_rates.h2h}%</span><span>Season ${data.hit_rates.season}%</span>
        </div>
        <div class="mini-chart"><div class="line-marker" style="bottom:${Math.min(92, data.line * 5)}px"></div>${data.recent_games.map(g => recentBar(g, data.line)).join('')}</div>
      </article>

      <article class="research-card">
        <div class="card-title">EZ Filters</div>
        <div class="chip-row"><span class="market-chip active">Expected Min ${data.overview.expected_minutes}</span><span class="market-chip">Usage ${data.overview.usage_pct}%</span></div>
        <div class="chip-row"><span class="market-chip">Vs Pace Rank #${data.overview.pace_rank}</span><span class="market-chip">Vs Def Rank #${data.overview.opp_rank}</span></div>
        <div class="metric-grid two">
          <div class="metric-box"><span>Avg Diff to Line</span><strong>${data.overview.line_delta > 0 ? '+' : ''}${data.overview.line_delta}</strong></div>
          <div class="metric-box"><span>Trend</span><strong>${data.overview.trend}</strong></div>
          <div class="metric-box"><span>P10/P50/P90</span><strong>${data.sim.p10} / ${data.sim.p50} / ${data.sim.p90}</strong></div>
          <div class="metric-box"><span>Under Chance</span><strong>${data.sim.p_under}%</strong></div>
        </div>
      </article>
    </div>

    <div class="research-grid">
      <article class="research-card">
        <div class="card-title">Shot Profile</div>
        <div class="shot-stack">${data.shot_profile.map(s => `<div class="shot-seg"><div class="shot-pct">${s.pct}%</div><div class="shot-name">${s.label}</div><div class="shot-rank">vs ${data.opponent} #${s.opp_rank}</div></div>`).join('')}</div>
      </article>

      <article class="research-card">
        <div class="card-title">${data.opponent} vs Position</div>
        <div class="metric-grid two">
          <div class="metric-box"><span>${fmtStat(data.market)}/36</span><strong>${data.vs_position.points_per_36}</strong></div>
          <div class="metric-box"><span>Rank</span><strong>#${data.vs_position.rank}</strong></div>
          <div class="metric-box"><span>Avg Diff to ${data.line}</span><strong>${data.vs_position.avg_diff_to_line > 0 ? '+' : ''}${data.vs_position.avg_diff_to_line}</strong></div>
          <div class="metric-box"><span>Diff %</span><strong>${data.vs_position.diff_pct_to_line > 0 ? '+' : ''}${data.vs_position.diff_pct_to_line}%</strong></div>
        </div>
      </article>
    </div>

    <div class="research-grid">
      <article class="research-card wide">
        <div class="card-title">Play Type Analysis</div>
        <div class="playtype-list">${data.playtypes.map(p => `<div class="playtype-row"><span>${p.name}</span><span>${p.pct_points}% of pts</span><span class="${p.opp_rank >= 20 ? 'good' : p.opp_rank <= 10 ? 'bad' : ''}">Opp #${p.opp_rank}</span></div>`).join('')}</div>
      </article>

      <article class="research-card wide">
        <div class="card-title">Vs Opponent</div>
        <div class="metric-grid three">
          <div class="metric-box"><span>Offense Rank</span><strong>#${data.matchup.offense_rank}</strong></div>
          <div class="metric-box"><span>Defense Rank</span><strong>#${data.matchup.defense_rank}</strong></div>
          <div class="metric-box"><span>Pace Rank</span><strong>#${data.matchup.pace_rank}</strong></div>
          <div class="metric-box"><span>Paint Scoring</span><strong>#${data.matchup.paint_rank}</strong></div>
          <div class="metric-box"><span>3PT Defense</span><strong>#${data.matchup.threes_rank}</strong></div>
          <div class="metric-box"><span>Rebounding</span><strong>#${data.matchup.rebounding_rank}</strong></div>
        </div>
      </article>
    </div>
  </section>`;
}

function renderMLB(data) {
  return `
  <section class="research-shell">
    <div class="research-hero">
      <div>
        <div class="eyebrow">${data.team} · ${data.team_name}</div>
        <h1>${data.player}</h1>
        <div class="hero-sub">${fmtStat(data.market)} vs ${data.opponent_name} · line ${data.line}</div>
      </div>
      <div class="hero-actions">${data.available_markets.map(m => marketButton(data, m)).join('')}</div>
    </div>

    <div class="research-grid top">
      <article class="research-card">
        <div class="kpi-row">
          <div><div class="kpi-label">Hit Rate</div><div class="kpi-big">${data.hit_rates.l10}%</div><div class="kpi-sub">L10 · Avg ${data.avg}</div></div>
          <div class="line-pill ${pctClass(data.sim.p_over)}">${data.sim.p_over}% over</div>
        </div>
        <div class="hit-tabs">
          <span>L5 ${data.hit_rates.l5}%</span><span>L10 ${data.hit_rates.l10}%</span><span>L20 ${data.hit_rates.l20}%</span><span>H2H ${data.hit_rates.h2h}%</span><span>Season ${data.hit_rates.season}%</span>
        </div>
        <div class="mini-chart"><div class="line-marker" style="bottom:${Math.min(92, data.line * 22)}px"></div>${data.recent_games.map(g => recentBar(g, data.line)).join('')}</div>
      </article>
      <article class="research-card">
        <div class="card-title">Research Snapshot</div>
        <div class="metric-grid two">
          <div class="metric-box"><span>${data.kind === 'pitcher' ? 'Projected IP' : 'Projected PA'}</span><strong>${data.overview.expected_volume}</strong></div>
          <div class="metric-box"><span>Park Factor</span><strong>${data.overview.park_factor}</strong></div>
          <div class="metric-box"><span>Opp Rank</span><strong>#${data.overview.opp_rank}</strong></div>
          <div class="metric-box"><span>Avg Diff to Line</span><strong>${data.overview.line_delta > 0 ? '+' : ''}${data.overview.line_delta}</strong></div>
        </div>
      </article>
    </div>

    <div class="research-grid">
      <article class="research-card wide">
        <div class="card-title">Splits</div>
        <div class="metric-grid four">${data.splits.map(s => `<div class="metric-box"><span>${s.label}</span><strong>${s.value}</strong></div>`).join('')}</div>
      </article>
    </div>
  </section>`;
}

fetch(`/api/player/${encodeURIComponent(player)}/research?sport=${encodeURIComponent(sport)}${opp ? `&opp=${encodeURIComponent(opp)}` : ''}${market ? `&market=${encodeURIComponent(market)}` : ''}`)
  .then(r => r.json())
  .then(data => {
    if (data.error) throw new Error(data.error);
    document.title = `PropEdge — ${data.player}`;
    page.innerHTML = data.sport === 'nba' ? renderNBA(data) : renderMLB(data);
  })
  .catch(err => {
    page.innerHTML = `<div class="loading"><span class="loading-text">${err.message}</span></div>`;
  });
