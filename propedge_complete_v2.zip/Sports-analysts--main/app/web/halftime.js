const snapshotEl = document.getElementById('snapshot-json');
const linesEl = document.getElementById('lines-json');
const boardOut = document.getElementById('board-out');

const demoSnapshot = {
  game_id: 'demo-tor-cle',
  home_team: 'CLE',
  away_team: 'TOR',
  home_score: 54,
  away_score: 49,
  clock: 'HALF',
  trials: 3000,
  players: [
    { player: 'Donovan Mitchell', team: 'CLE', opponent: 'TOR', minutes: 18, fouls: 1, points: 17, rebounds: 3, assists: 4, threes_made: 2, steals: 1, blocks: 0, turnovers: 2, starters_role: 'star' },
    { player: 'Darius Garland', team: 'CLE', opponent: 'TOR', minutes: 17, fouls: 2, points: 11, rebounds: 1, assists: 5, threes_made: 1, steals: 0, blocks: 0, turnovers: 1, starters_role: 'starter' },
    { player: 'Evan Mobley', team: 'CLE', opponent: 'TOR', minutes: 19, fouls: 2, points: 10, rebounds: 8, assists: 2, threes_made: 0, steals: 0, blocks: 2, turnovers: 1, starters_role: 'starter' },
    { player: 'Scottie Barnes', team: 'TOR', opponent: 'CLE', minutes: 19, fouls: 1, points: 14, rebounds: 4, assists: 5, threes_made: 1, steals: 1, blocks: 0, turnovers: 1, starters_role: 'star' },
    { player: 'RJ Barrett', team: 'TOR', opponent: 'CLE', minutes: 18, fouls: 2, points: 13, rebounds: 3, assists: 2, threes_made: 2, steals: 0, blocks: 0, turnovers: 2, starters_role: 'starter' },
    { player: 'Jakob Poeltl', team: 'TOR', opponent: 'CLE', minutes: 16, fouls: 3, points: 6, rebounds: 7, assists: 1, threes_made: 0, steals: 0, blocks: 1, turnovers: 1, starters_role: 'starter' }
  ]
};

const demoLines = {
  sport: 'nba',
  game_id: 'demo-tor-cle',
  lines: [
    { player: 'Donovan Mitchell', market: 'points', line: 29.5, over_odds: -120, under_odds: -110, book: 'bet365' },
    { player: 'Donovan Mitchell', market: 'assists', line: 6.5, over_odds: -110, under_odds: -120, book: 'bet365' },
    { player: 'Scottie Barnes', market: 'points', line: 22.5, over_odds: -115, under_odds: -115, book: 'bet365' },
    { player: 'Scottie Barnes', market: 'pra', line: 31.5, over_odds: -110, under_odds: -120, book: 'bet365' },
    { player: 'Evan Mobley', market: 'rebounds', line: 11.5, over_odds: -105, under_odds: -125, book: 'bet365' },
    { player: 'RJ Barrett', market: 'points', line: 20.5, over_odds: -110, under_odds: -120, book: 'bet365' }
  ]
};

function renderBoard(data) {
  if (!data.board || !data.board.length) {
    boardOut.innerHTML = '<p>No board rows found.</p>';
    return;
  }
  const top = data.board.slice(0, 20);
  boardOut.innerHTML = `
    <div style="margin:12px 0 4px 0;color:#9db0d7">${data.away_team} @ ${data.home_team} — ${data.away_score}-${data.home_score}</div>
    <table class="hf-table">
      <thead><tr><th>Player</th><th>Market</th><th>Live proj</th><th>Line</th><th>Over %</th><th>Edge</th><th>Tag</th></tr></thead>
      <tbody>
      ${top.map(row => {
        const cls = row.classification.startsWith('strong') ? 'strong' : row.classification.startsWith('lean') ? 'lean' : 'trap';
        return `<tr>
          <td>${row.player}</td>
          <td>${row.market}</td>
          <td>${row.live_projection.mean}</td>
          <td>${row.line}</td>
          <td>${(row.probabilities.p_over*100).toFixed(1)}%</td>
          <td>${row.edge.side || '-'} ${row.edge.edge_pct}%</td>
          <td><span class="pill ${cls}">${row.classification}</span></td>
        </tr>`;
      }).join('')}
      </tbody>
    </table>`;
}

async function postJson(url, payload) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
  return r.json();
}

document.getElementById('seed-demo').onclick = () => { snapshotEl.value = JSON.stringify(demoSnapshot, null, 2); };
document.getElementById('seed-lines').onclick = () => { linesEl.value = JSON.stringify(demoLines, null, 2); };
document.getElementById('save-snapshot').onclick = async () => {
  const payload = JSON.parse(snapshotEl.value);
  const data = await postJson('/api/live/import/nba-halftime', payload);
  alert(`Snapshot uploaded for ${data.game_id}`);
};
document.getElementById('save-lines').onclick = async () => {
  const payload = JSON.parse(linesEl.value);
  const data = await postJson('/api/live/import/book-lines', payload);
  alert(`Lines uploaded for ${data.game_id}`);
};
document.getElementById('load-board').onclick = async () => {
  const gameId = document.getElementById('watchlist-game-id').value.trim();
  const r = await fetch(`/api/live/nba/halftime-board?game_id=${encodeURIComponent(gameId)}`);
  const data = await r.json();
  renderBoard(data);
};

snapshotEl.value = JSON.stringify(demoSnapshot, null, 2);
linesEl.value = JSON.stringify(demoLines, null, 2);
