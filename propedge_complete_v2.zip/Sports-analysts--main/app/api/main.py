"""FastAPI backend. Serves the web UI and JSON endpoints.

Run:
    uvicorn app.api.main:app --reload
or:
    python -m app.api.main
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

_env_path = Path(__file__).resolve().parent.parent / ".env"
load_dotenv(_env_path)

from fastapi import FastAPI, Query, Body
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.api.pipeline import build_board
from app.api.research import build_player_research, list_teams, list_players, grouped_players
from app.core.math_utils import american_to_decimal
from app.live.store import STORE
from app.live.models import NbaHalftimeImport, BookLinesImport
from app.live.halftime import build_nba_halftime_board

WEB_DIR = Path(__file__).resolve().parent.parent / "web"

app = FastAPI(title="Sports Prop Research", version="0.2.0")
app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")


@app.get("/")
def index():
    return FileResponse(WEB_DIR / "index.html")


@app.get("/research")
def research_page():
    return FileResponse(WEB_DIR / "research.html")


@app.get("/directory")
def directory_page():
    return FileResponse(WEB_DIR / "directory.html")


@app.get("/halftime")
def halftime_page():
    return FileResponse(WEB_DIR / "halftime.html")


# ---------- Core board ----------

@app.get("/api/board")
def board(
    sport: str = Query("nba", pattern="^(nba|mlb)$"),
    phase: str = Query("pregame", pattern="^(pregame|live)$"),
):
    cards = build_board(sport, phase=phase)
    return JSONResponse({"sport": sport, "phase": phase, "cards": cards})


# ---------- Player search ----------

@app.get("/api/search")
def search_players(q: str = Query("", min_length=1), sport: str = Query("nba", pattern="^(nba|mlb)$")):
    """Search for players by name fragment. Returns matching names."""
    q_lower = q.lower()
    if sport == "nba":
        from app.data.nba_stats import NBA_PLAYERS
        matches = [name for name in NBA_PLAYERS if q_lower in name.lower()]
    else:
        from app.data.mlb_stats import MLB_HITTERS, MLB_PITCHERS
        all_names = list(MLB_HITTERS.keys()) + list(MLB_PITCHERS.keys())
        matches = [name for name in all_names if q_lower in name.lower()]
    return {"sport": sport, "query": q, "results": sorted(set(matches))[:20]}


@app.get("/api/player/{player_name}")
def player_detail(player_name: str, sport: str = Query("nba", pattern="^(nba|mlb)$")):
    """Get all available stats and projections for a specific player."""
    from app.data.providers import get_stats_provider
    from app.core.simulator import Projection, simulate_prop
    from app.sports.nba.markets import NBA_MARKETS
    from app.sports.mlb.markets import MLB_MARKETS

    stats_provider = get_stats_provider()
    markets = NBA_MARKETS if sport == "nba" else MLB_MARKETS
    trials = int(os.environ.get("SIM_TRIALS", "1000"))

    props = []
    for stat_name in markets:
        try:
            ctx = stats_provider.player_context(sport, player_name, stat_name)
        except KeyError:
            continue

        if sport == "nba":
            from app.sports.nba.projection import PlayerContext, project_pregame
            proj = project_pregame(PlayerContext(player=player_name, stat=stat_name, **ctx))
        else:
            kind = ctx.pop("kind", "hitter")
            if kind == "hitter":
                from app.sports.mlb.projection import HitterContext, project_hitter
                proj = project_hitter(HitterContext(player=player_name, stat=stat_name, **ctx))
            else:
                from app.sports.mlb.projection import PitcherContext, project_pitcher
                proj = project_pitcher(PitcherContext(player=player_name, stat=stat_name, **ctx))

        props.append({
            "stat": stat_name,
            "mean": proj.mean,
            "sd": proj.sd,
            "dist": proj.dist,
        })

    if not props:
        return JSONResponse({"error": f"Player not found: {player_name}"}, status_code=404)
    return {"player": player_name, "sport": sport, "props": props}




@app.get("/api/teams")
def teams(sport: str = Query("nba", pattern="^(nba|mlb)$")):
    return {"sport": sport, "teams": list_teams(sport)}


@app.get("/api/players")
def players(
    sport: str = Query("nba", pattern="^(nba|mlb)$"),
    team: Optional[str] = Query(None),
    grouped: bool = Query(False),
):
    if grouped:
        return {"sport": sport, "groups": grouped_players(sport)}
    return {"sport": sport, "players": list_players(sport, team)}


@app.get("/api/player/{player_name}/research")
def player_research(
    player_name: str,
    sport: str = Query("nba", pattern="^(nba|mlb)$"),
    opp: Optional[str] = Query(None),
    market: Optional[str] = Query(None),
):
    try:
        payload = build_player_research(sport=sport, player=player_name, opp=opp, market=market)
    except KeyError:
        return JSONResponse({"error": f"Player not found: {player_name}"}, status_code=404)
    return payload


# ---------- Parlay builder ----------

@app.post("/api/parlay")
def build_parlay_endpoint(legs: list[dict] = Body(...)):
    """Price a parlay. Each leg: {player, stat, side, model_prob, game_id, sport, odds}."""
    from app.core.parlay import ParlayLeg, build_parlay

    parlay_legs = []
    for leg in legs:
        try:
            parlay_legs.append(ParlayLeg(
                player=leg["player"],
                stat=leg["stat"],
                side=leg["side"],
                model_prob=float(leg["model_prob"]),
                game_id=leg.get("game_id", ""),
                sport=leg.get("sport", "nba"),
                decimal_odds=american_to_decimal(int(leg["odds"])),
            ))
        except (KeyError, ValueError) as e:
            return JSONResponse({"error": f"Invalid leg: {e}"}, status_code=400)

    if len(parlay_legs) < 2:
        return JSONResponse({"error": "Need at least 2 legs"}, status_code=400)

    result = build_parlay(parlay_legs)
    return {
        "naive_prob": result.naive_prob,
        "correlated_prob": result.correlated_prob,
        "combined_odds": result.combined_decimal_odds,
        "ev_per_dollar": result.ev_per_dollar,
        "is_positive_ev": result.is_positive_ev,
        "correlation_penalty": result.correlation_penalty,
        "legs": len(result.legs),
    }


# ---------- Backtest ----------

@app.get("/api/backtest")
def run_backtest_endpoint(
    n_games: int = Query(200, ge=50, le=2000),
    min_edge: float = Query(3.0, ge=0.0),
):
    """Run a backtest on synthetic history."""
    from app.backtest.engine import generate_synthetic_history, run_backtest

    history = generate_synthetic_history(n_games=n_games)
    report = run_backtest(history, min_edge_pct=min_edge)
    return {
        "total_games": report.total_games,
        "picks_made": report.picks_made,
        "wins": report.wins,
        "losses": report.losses,
        "win_rate": report.win_rate,
        "flat_roi_pct": report.flat_roi_pct,
        "kelly_roi_pct": report.kelly_roi_pct,
        "mean_edge_pct": report.mean_edge_pct,
        "calibration": report.calibration,
        "by_sport": report.by_sport,
        "by_stat": report.by_stat,
    }


# ---------- Live scores ----------

@app.get("/api/live/nba")
def live_nba():
    """Get live NBA scoreboard from ESPN."""
    from app.data.live_scores import LiveScoresFeed
    feed = LiveScoresFeed()
    games = feed.nba_scoreboard()
    return {
        "games": [
            {
                "game_id": g.game_id,
                "home": g.home_team,
                "away": g.away_team,
                "score": f"{g.away_score}-{g.home_score}",
                "quarter": g.quarter,
                "clock": g.clock,
                "is_halftime": g.is_halftime,
                "is_final": g.is_final,
                "is_blowout": g.is_blowout,
            }
            for g in games
        ]
    }


@app.get("/api/live/mlb")
def live_mlb():
    """Get today's MLB schedule and live status."""
    from app.data.live_scores import LiveScoresFeed
    feed = LiveScoresFeed()
    return {"games": feed.mlb_schedule_today()}


@app.post("/api/live/import/nba-halftime")
def import_nba_halftime(payload: NbaHalftimeImport):
    STORE.put_nba_halftime(payload.game_id, payload.model_dump())
    return {"ok": True, "game_id": payload.game_id, "players": len(payload.players)}


@app.post("/api/live/import/book-lines")
def import_book_lines(payload: BookLinesImport):
    STORE.put_lines(payload.sport, payload.game_id, payload.model_dump())
    return {"ok": True, "sport": payload.sport, "game_id": payload.game_id, "lines": len(payload.lines)}


@app.get("/api/live/import/status")
def live_import_status():
    return STORE.status()


@app.get("/api/live/nba/halftime-board")
def nba_halftime_board(game_id: str = Query(...)):
    snapshot = STORE.get_nba_halftime(game_id)
    if not snapshot:
        return JSONResponse({"error": f"No halftime snapshot loaded for {game_id}"}, status_code=404)
    lines = STORE.get_lines("nba", game_id)
    return build_nba_halftime_board(snapshot, lines)


@app.get("/api/live/nba/watchlist")
def nba_halftime_watchlist(min_edge: float = Query(4.0, ge=0.0)):
    games = []
    for game_id, snapshot in STORE.all_nba_halftime().items():
        lines = STORE.get_lines("nba", game_id)
        board = build_nba_halftime_board(snapshot, lines)
        top = [row for row in board["board"] if row["edge"]["edge_pct"] >= min_edge][:15]
        games.append({
            "game_id": game_id,
            "matchup": f"{board['away_team']} @ {board['home_team']}",
            "home_score": board["home_score"],
            "away_score": board["away_score"],
            "top_edges": top,
        })
    return {"games": games, "min_edge": min_edge}


# ---------- Status ----------

@app.get("/api/health")
def health():
    return {"ok": True}


@app.get("/api/status")
def status():
    return {
        "odds_provider": "live" if os.environ.get("ODDS_API_KEY", "").strip() else "mock",
        "stats_provider": "database",
        "nba_players": _count_nba(),
        "mlb_players": _count_mlb(),
        "ai_enabled": bool(os.environ.get("ANTHROPIC_API_KEY", "").strip()),
    }


def _count_nba() -> int:
    try:
        from app.data.nba_stats import NBA_PLAYERS
        return len(NBA_PLAYERS)
    except Exception:
        return 0


def _count_mlb() -> int:
    try:
        from app.data.mlb_stats import MLB_HITTERS, MLB_PITCHERS
        return len(MLB_HITTERS) + len(MLB_PITCHERS)
    except Exception:
        return 0


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("app.api.main:app", host="0.0.0.0", port=port, reload=False)
