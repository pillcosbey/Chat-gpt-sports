from __future__ import annotations

import math
from collections import defaultdict
from typing import Any

import numpy as np

from app.core.simulator import Projection, simulate_prop
from app.data.nba_stats import NBA_PLAYERS, NBA_DEFENSE, NBA_PACE
from app.data.mlb_stats import MLB_HITTERS, MLB_PITCHERS

NBA_TEAMS = {
    'ATL': 'Atlanta Hawks', 'BOS': 'Boston Celtics', 'BKN': 'Brooklyn Nets', 'CHA': 'Charlotte Hornets',
    'CHI': 'Chicago Bulls', 'CLE': 'Cleveland Cavaliers', 'DAL': 'Dallas Mavericks', 'DEN': 'Denver Nuggets',
    'DET': 'Detroit Pistons', 'GSW': 'Golden State Warriors', 'HOU': 'Houston Rockets', 'IND': 'Indiana Pacers',
    'LAC': 'Los Angeles Clippers', 'LAL': 'Los Angeles Lakers', 'MEM': 'Memphis Grizzlies', 'MIA': 'Miami Heat',
    'MIL': 'Milwaukee Bucks', 'MIN': 'Minnesota Timberwolves', 'NOP': 'New Orleans Pelicans', 'NYK': 'New York Knicks',
    'OKC': 'Oklahoma City Thunder', 'ORL': 'Orlando Magic', 'PHI': 'Philadelphia 76ers', 'PHX': 'Phoenix Suns',
    'POR': 'Portland Trail Blazers', 'SAC': 'Sacramento Kings', 'SAS': 'San Antonio Spurs', 'TOR': 'Toronto Raptors',
    'UTA': 'Utah Jazz', 'WAS': 'Washington Wizards'
}

MLB_TEAMS = {
    'ARI': 'Arizona Diamondbacks', 'ATL': 'Atlanta Braves', 'BAL': 'Baltimore Orioles', 'BOS': 'Boston Red Sox',
    'CHC': 'Chicago Cubs', 'CWS': 'Chicago White Sox', 'CIN': 'Cincinnati Reds', 'CLE': 'Cleveland Guardians',
    'COL': 'Colorado Rockies', 'DET': 'Detroit Tigers', 'HOU': 'Houston Astros', 'KC': 'Kansas City Royals',
    'LAA': 'Los Angeles Angels', 'LAD': 'Los Angeles Dodgers', 'MIA': 'Miami Marlins', 'MIL': 'Milwaukee Brewers',
    'MIN': 'Minnesota Twins', 'NYM': 'New York Mets', 'NYY': 'New York Yankees', 'OAK': 'Athletics', 'PHI': 'Philadelphia Phillies',
    'PIT': 'Pittsburgh Pirates', 'SD': 'San Diego Padres', 'SEA': 'Seattle Mariners', 'SF': 'San Francisco Giants',
    'STL': 'St. Louis Cardinals', 'TB': 'Tampa Bay Rays', 'TEX': 'Texas Rangers', 'TOR': 'Toronto Blue Jays', 'WSH': 'Washington Nationals'
}

NBA_OPP_CYCLE = list(NBA_TEAMS)
MLB_OPP_CYCLE = list(MLB_TEAMS)

NBA_MARKETS = ['points', 'rebounds', 'assists', 'threes_made', 'pra', 'steals', 'blocks']
MLB_HITTER_MARKETS = ['hits', 'total_bases', 'runs', 'rbis', 'home_runs', 'stolen_bases', 'walks']
MLB_PITCHER_MARKETS = ['strikeouts', 'outs_recorded', 'hits_allowed', 'earned_runs', 'walks_allowed']

SHOT_TYPES = ['Rim', 'Mid / ITP', '3PT']
PLAY_TYPES = ['Transition', 'Free Throws', 'Spot Up', 'PnR Ball Handler', 'Isolation', 'Off Screen', 'Post Up', 'Handoff', 'Cut']


def _seed(*parts: str) -> int:
    return abs(hash('|'.join(parts))) % (2**32)


def _rng(*parts: str):
    return np.random.default_rng(_seed(*parts))


def _slug(text: str) -> str:
    return ''.join(ch.lower() if ch.isalnum() else '-' for ch in text).strip('-')


def list_teams(sport: str) -> list[dict[str, Any]]:
    source = NBA_TEAMS if sport == 'nba' else MLB_TEAMS
    return [{'code': code, 'name': name} for code, name in sorted(source.items(), key=lambda x: x[1])]


def list_players(sport: str, team: str | None = None) -> list[dict[str, Any]]:
    players: list[dict[str, Any]] = []
    if sport == 'nba':
        for name, info in NBA_PLAYERS.items():
            if team and info['team'] != team:
                continue
            players.append({'name': name, 'team': info['team'], 'team_name': NBA_TEAMS.get(info['team'], info['team'])})
    else:
        for source in (MLB_HITTERS, MLB_PITCHERS):
            for name, info in source.items():
                if team and info['team'] != team:
                    continue
                players.append({'name': name, 'team': info['team'], 'team_name': MLB_TEAMS.get(info['team'], info['team'])})
    players.sort(key=lambda x: x['name'])
    return players


def grouped_players(sport: str) -> list[dict[str, Any]]:
    buckets = defaultdict(list)
    for p in list_players(sport):
        buckets[p['team']].append(p)
    teams_meta = NBA_TEAMS if sport == 'nba' else MLB_TEAMS
    out = []
    for code, team_name in sorted(teams_meta.items(), key=lambda x: x[1]):
        out.append({'team': code, 'team_name': team_name, 'players': buckets.get(code, [])})
    return out


def _nba_player_info(player: str) -> dict[str, Any]:
    data = NBA_PLAYERS[player]
    return data


def _mlb_player_info(player: str) -> tuple[str, dict[str, Any]]:
    if player in MLB_HITTERS:
        return 'hitter', MLB_HITTERS[player]
    if player in MLB_PITCHERS:
        return 'pitcher', MLB_PITCHERS[player]
    raise KeyError(player)


def _recent_series(mean: float, sd: float, count: int, floor: float, player: str, stat: str) -> list[float]:
    rng = _rng(player, stat, 'recent')
    vals = rng.normal(mean, max(sd, 0.8), size=count)
    vals = np.clip(vals, floor, None)
    return [round(float(v), 1) for v in vals]


def _line_from_mean(mean: float, sport: str, stat: str) -> float:
    if sport == 'nba':
        if stat in {'points', 'pra'}:
            return round(mean + 1.5) - 0.5
        if stat in {'rebounds', 'assists'}:
            return round(mean + 0.5) - 0.5
        return round(mean) - 0.5
    if stat in {'outs_recorded'}:
        return round(mean)
    if stat in {'hits', 'total_bases', 'runs', 'rbis', 'walks', 'earned_runs', 'hits_allowed'}:
        return round(mean, 1)
    return round(mean + 0.5) - 0.5


def _sim(mean: float, sd: float, line: float, player: str, stat: str, dist: str = 'negbin') -> dict[str, Any]:
    proj = Projection(player=player, stat=stat, mean=max(mean, 0.01), sd=max(sd, 0.35), dist=dist)
    sim = simulate_prop(proj, line, trials=3000, seed=_seed(player, stat, 'sim'))
    return {
        'p_over': round(sim.p_over * 100, 1),
        'p_under': round(sim.p_under * 100, 1),
        'p10': round(sim.p10, 1),
        'p50': round(sim.p50, 1),
        'p90': round(sim.p90, 1),
    }


def build_player_research(sport: str, player: str, opp: str | None = None, market: str | None = None) -> dict[str, Any]:
    if sport == 'nba':
        info = _nba_player_info(player)
        team = info['team']
        if not opp or opp == team:
            cycle = [t for t in NBA_OPP_CYCLE if t != team]
            opp = cycle[_seed(player, 'opp') % len(cycle)]
        market = market or 'points'
        if market not in info and market not in {'pra'}:
            market = 'points'
        if market == 'pra':
            mean = info['points'][0] + info['rebounds'][0] + info['assists'][0]
            sd = (info['points'][1] + info['rebounds'][1] + info['assists'][1]) * 0.7
        else:
            mean, sd = info[market]
        line = _line_from_mean(mean, sport, market)
        recent10 = _recent_series(mean, sd, 10, 0, player, market)
        recent5 = recent10[-5:]
        recent20 = _recent_series(mean, sd, 20, 0, player, market)
        hit10 = sum(v > line for v in recent10)
        hit5 = sum(v > line for v in recent5)
        hit20 = sum(v > line for v in recent20)
        sim = _sim(mean, sd, line, player, market)
        team_pace_rank = sorted(NBA_PACE.items(), key=lambda x: x[1], reverse=True)
        pace_rank_map = {code: i+1 for i, (code, _) in enumerate(team_pace_rank)}
        defense_rank = NBA_DEFENSE.get(opp, {}).get('points' if market == 'pra' else market, 15)
        shot_rng = _rng(player, 'shot')
        rim = round(float(shot_rng.uniform(14, 28)), 1)
        threes = round(float(shot_rng.uniform(18, 34)), 1)
        mid = round(100 - rim - threes, 1)
        shot_profile = [
            {'label': 'Rim', 'pct': rim, 'opp_rank': int(shot_rng.integers(3, 29))},
            {'label': 'Mid / ITP', 'pct': mid, 'opp_rank': int(shot_rng.integers(3, 29))},
            {'label': '3PT', 'pct': threes, 'opp_rank': int(shot_rng.integers(3, 29))},
        ]
        pt_rng = _rng(player, 'playtype')
        playtypes = []
        remaining = 100.0
        for i, label in enumerate(PLAY_TYPES):
            pct = round(float(pt_rng.uniform(3.0, 18.0 if i < 3 else 12.0)), 1)
            remaining -= pct
            playtypes.append({'name': label, 'pct_points': pct, 'opp_rank': int(pt_rng.integers(2, 30))})
        playtypes = sorted(playtypes, key=lambda x: x['pct_points'], reverse=True)[:8]
        trend = 'up' if hit5 >= 3 else 'flat' if hit5 == 2 else 'down'
        return {
            'sport': sport,
            'player': player,
            'player_slug': _slug(player),
            'team': team,
            'team_name': NBA_TEAMS.get(team, team),
            'opponent': opp,
            'opponent_name': NBA_TEAMS.get(opp, opp),
            'market': market,
            'line': line,
            'avg': round(mean, 1),
            'sd': round(sd, 1),
            'sim': sim,
            'hit_rates': {
                'l5': round(hit5 / 5 * 100),
                'l10': round(hit10 / 10 * 100),
                'l20': round(hit20 / 20 * 100),
                'season': round(sim['p_over']),
                'h2h': round(max(5, min(95, sim['p_over'] - 12))),
            },
            'recent_games': [{'label': f'G{i+1}', 'value': v, 'hit': v > line} for i, v in enumerate(recent10)],
            'overview': {
                'expected_minutes': round(info['min'] + (_seed(player, 'min') % 5 - 2) * 0.5, 1),
                'usage_pct': round(float(_rng(player, 'usage').uniform(18, 34)), 1),
                'pace_rank': pace_rank_map.get(team, 15),
                'opp_rank': defense_rank,
                'line_delta': round(mean - line, 1),
                'trend': trend,
            },
            'shot_profile': shot_profile,
            'vs_position': {
                'points_per_36': round(float(_rng(player, 'pos').uniform(18, 32)), 1),
                'rank': int(_rng(player, 'posr').integers(1, 31)),
                'avg_diff_to_line': round(mean - line, 1),
                'diff_pct_to_line': round(((mean - line) / max(line, 1)) * 100),
            },
            'playtypes': playtypes,
            'matchup': {
                'offense_rank': int(_rng(player, 'off').integers(1, 31)),
                'defense_rank': int(_rng(player, 'def').integers(1, 31)),
                'pace_rank': pace_rank_map.get(team, 15),
                'paint_rank': NBA_DEFENSE.get(opp, {}).get('points', 15),
                'threes_rank': NBA_DEFENSE.get(opp, {}).get('threes_made', 15),
                'rebounding_rank': NBA_DEFENSE.get(opp, {}).get('rebounds', 15),
            },
            'available_markets': [m for m in NBA_MARKETS if m in info or m == 'pra'],
        }

    # MLB
    kind, info = _mlb_player_info(player)
    team = info['team']
    if not opp or opp == team:
        cycle = [t for t in MLB_OPP_CYCLE if t != team]
        opp = cycle[_seed(player, 'opp') % len(cycle)]
    if kind == 'hitter':
        available = [m for m in MLB_HITTER_MARKETS if m in info]
    else:
        available = [m for m in MLB_PITCHER_MARKETS if m in info]
    market = market or available[0]
    if market not in available:
        market = available[0]
    mean_per, sd = info[market]
    volume = info['pas'] if kind == 'hitter' else info['ip']
    mean = mean_per * volume
    line = _line_from_mean(mean, sport, market)
    recent10 = _recent_series(mean, sd, 10, 0, player, market)
    recent5 = recent10[-5:]
    recent20 = _recent_series(mean, sd, 20, 0, player, market)
    hit10 = sum(v > line for v in recent10)
    hit5 = sum(v > line for v in recent5)
    hit20 = sum(v > line for v in recent20)
    dist = 'poisson' if market in {'home_runs', 'stolen_bases', 'earned_runs'} else 'negbin'
    sim = _sim(mean, sd, line, player, market, dist=dist)
    return {
        'sport': sport,
        'player': player,
        'player_slug': _slug(player),
        'team': team,
        'team_name': MLB_TEAMS.get(team, team),
        'opponent': opp,
        'opponent_name': MLB_TEAMS.get(opp, opp),
        'market': market,
        'line': line,
        'avg': round(mean, 2),
        'sd': round(sd, 2),
        'sim': sim,
        'kind': kind,
        'hit_rates': {
            'l5': round(hit5 / 5 * 100),
            'l10': round(hit10 / 10 * 100),
            'l20': round(hit20 / 20 * 100),
            'season': round(sim['p_over']),
            'h2h': round(max(5, min(95, sim['p_over'] - 8))),
        },
        'recent_games': [{'label': f'G{i+1}', 'value': v, 'hit': v > line} for i, v in enumerate(recent10)],
        'overview': {
            'expected_volume': round(volume, 1),
            'park_factor': round(float(_rng(player, 'park').uniform(0.92, 1.12)), 2),
            'opp_rank': int(_rng(player, 'oppr').integers(1, 31)),
            'line_delta': round(mean - line, 2),
            'trend': 'up' if hit5 >= 3 else 'flat' if hit5 == 2 else 'down',
        },
        'splits': [
            {'label': 'Home', 'value': round(mean * 1.03, 2)},
            {'label': 'Away', 'value': round(mean * 0.97, 2)},
            {'label': 'Last 10', 'value': round(sum(recent10) / len(recent10), 2)},
            {'label': 'Vs RHP/LHP', 'value': round(mean * float(_rng(player, 'hand').uniform(0.9, 1.1)), 2)},
        ],
        'available_markets': available,
    }
