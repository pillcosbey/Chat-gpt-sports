from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class SnapshotBucket:
    snapshots: dict[str, dict[str, Any]] = field(default_factory=dict)
    updated_at: str = field(default_factory=_utcnow)

    def put(self, key: str, value: dict[str, Any]) -> None:
        self.snapshots[key] = value
        self.updated_at = _utcnow()

    def get(self, key: str) -> dict[str, Any] | None:
        return self.snapshots.get(key)

    def all(self) -> dict[str, dict[str, Any]]:
        return self.snapshots


class LiveResearchStore:
    """In-memory store for imported live snapshots and sportsbook lines.

    This keeps the app usable without adding Redis/Postgres first. Once the
    system is live in production, move these buckets to Redis or Postgres and
    retain time-series history for backtesting.
    """

    def __init__(self) -> None:
        self._nba_halftime = SnapshotBucket()
        self._mlb_live = SnapshotBucket()
        self._book_lines = SnapshotBucket()

    def put_nba_halftime(self, game_id: str, snapshot: dict[str, Any]) -> None:
        self._nba_halftime.put(game_id, snapshot)

    def get_nba_halftime(self, game_id: str) -> dict[str, Any] | None:
        return self._nba_halftime.get(game_id)

    def all_nba_halftime(self) -> dict[str, dict[str, Any]]:
        return self._nba_halftime.all()

    def put_mlb_live(self, game_id: str, snapshot: dict[str, Any]) -> None:
        self._mlb_live.put(game_id, snapshot)

    def get_mlb_live(self, game_id: str) -> dict[str, Any] | None:
        return self._mlb_live.get(game_id)

    def put_lines(self, sport: str, game_id: str, snapshot: dict[str, Any]) -> None:
        self._book_lines.put(f"{sport}:{game_id}", snapshot)

    def get_lines(self, sport: str, game_id: str) -> dict[str, Any] | None:
        return self._book_lines.get(f"{sport}:{game_id}")

    def status(self) -> dict[str, Any]:
        return {
            "nba_halftime_games": len(self._nba_halftime.snapshots),
            "mlb_live_games": len(self._mlb_live.snapshots),
            "book_line_games": len(self._book_lines.snapshots),
            "updated_at": {
                "nba_halftime": self._nba_halftime.updated_at,
                "mlb_live": self._mlb_live.updated_at,
                "book_lines": self._book_lines.updated_at,
            },
        }


STORE = LiveResearchStore()
