"""Live engines for halftime and in-game ingestion."""
