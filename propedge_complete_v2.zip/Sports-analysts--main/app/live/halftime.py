from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from app.core.math_utils import american_to_decimal, devig_two_way, edge_and_kelly, sportsbook_margin
from app.core.simulator import simulate_prop
from app.data.nba_stats import NBA_PLAYERS
from app.data.providers import get_stats_provider
from app.sports.nba.live import LiveGameState, project_live
from app.sports.nba.projection import PlayerContext, project_pregame


@dataclass
class HalftimePlayerStat:
    player: str
    team: str
    opponent: str
    minutes: float
    fouls: int = 0
    points: int = 0
    rebounds: int = 0
    assists: int = 0
    threes_made: int = 0
    steals: int = 0
    blocks: int = 0
    turnovers: int = 0
    starters_role: str = "rotation"


STAT_GETTERS = {
    "points": lambda p: p.points,
    "rebounds": lambda p: p.rebounds,
    "assists": lambda p: p.assists,
    "threes_made": lambda p: p.threes_made,
    "steals": lambda p: p.steals,
    "blocks": lambda p: p.blocks,
    "pra": lambda p: p.points + p.rebounds + p.assists,
}


DEFAULT_MARKETS = ["points", "rebounds", "assists", "threes_made", "pra"]


def _safe_team(player: str) -> str:
    data = NBA_PLAYERS.get(player, {})
    return data.get("team", "")


def _base_ctx(player: str, stat: str, opp: str | None = None) -> PlayerContext:
    raw = get_stats_provider("nba").player_context("nba", player, stat)
    return PlayerContext(player=player, stat=stat, **raw)


def _role_multiplier(role: str) -> float:
    role = (role or "rotation").lower()
    if role in {"star", "alpha"}:
        return 1.08
    if role in {"closer", "starter"}:
        return 1.04
    if role in {"bench", "reserve"}:
        return 0.93
    return 1.0


def _blowout_adjust(score_diff: int) -> float:
    if abs(score_diff) >= 25:
        return 0.72
    if abs(score_diff) >= 18:
        return 0.84
    if abs(score_diff) >= 12:
        return 0.92
    return 1.0


def _pace_multiplier(first_half_total: int) -> float:
    # 110 points at half ~ neutral modern game environment
    if first_half_total <= 90:
        return 0.94
    if first_half_total >= 130:
        return 1.06
    return max(0.94, min(1.06, first_half_total / 110.0))


def classify_prop_state(edge_pct: float, p_over: float, side: str | None, fouls: int, score_diff: int) -> str:
    if fouls >= 4:
        return "foul-risk sensitive"
    if abs(score_diff) >= 20:
        return "garbage-time sensitive"
    if side is None:
        return "dead line"
    if edge_pct >= 8:
        return f"strong {side.lower()}"
    if edge_pct >= 4:
        return f"lean {side.lower()}"
    if 47 <= p_over * 100 <= 53:
        return "volatile line"
    return "trap line"


def simulate_nba_halftime_prop(
    player_state: HalftimePlayerStat,
    line: float,
    over_odds: int,
    under_odds: int,
    stat: str,
    first_half_total_points: int,
    score_diff: int,
    trials: int = 2500,
) -> dict[str, Any]:
    ctx = _base_ctx(player_state.player, stat=stat, opp=player_state.opponent)
    pregame = project_pregame(ctx)

    current_stat = float(STAT_GETTERS[stat](player_state))
    base_per_min = pregame.mean / max(ctx.minutes_projection, 1.0)
    live_per_min = current_stat / max(player_state.minutes, 1.0)
    role_mult = _role_multiplier(player_state.starters_role)
    pace_mult = _pace_multiplier(first_half_total_points)
    on_pace = max(0.75, min(1.35, (live_per_min / max(base_per_min, 0.01)) * role_mult * pace_mult))

    projection, _ = project_live(
        ctx,
        LiveGameState(
            minutes_played=player_state.minutes,
            current_stat=current_stat,
            on_pace_multiplier=on_pace,
            blowout_adjust=_blowout_adjust(score_diff),
            foul_trouble=player_state.fouls >= 4,
        ),
    )
    sim = simulate_prop(projection, line, trials=trials)
    fair_over, fair_under = devig_two_way(over_odds, under_odds)
    edge = edge_and_kelly(
        model_p_over=sim.p_over,
        over_odds=over_odds,
        under_odds=under_odds,
        kelly_fraction_cap=0.25,
        min_edge_pct=0.0,
    )
    side = edge.side if edge else None
    edge_pct = edge.edge_pct if edge else 0.0
    hold_pct = round(sportsbook_margin(over_odds, under_odds) * 100, 2)

    return {
        "player": player_state.player,
        "team": player_state.team,
        "opponent": player_state.opponent,
        "market": stat,
        "line": line,
        "odds": {
            "over": over_odds,
            "under": under_odds,
            "over_decimal": round(american_to_decimal(over_odds), 3),
            "under_decimal": round(american_to_decimal(under_odds), 3),
            "hold_pct": hold_pct,
        },
        "halftime": {
            **asdict(player_state),
            "current_stat": current_stat,
            "score_diff": score_diff,
            "first_half_total_points": first_half_total_points,
        },
        "pregame_projection": {
            "mean": pregame.mean,
            "sd": pregame.sd,
        },
        "live_projection": {
            "mean": projection.mean,
            "sd": projection.sd,
            "p10": round(sim.p10, 2),
            "p50": round(sim.p50, 2),
            "p90": round(sim.p90, 2),
        },
        "probabilities": {
            "p_over": round(sim.p_over, 4),
            "p_under": round(sim.p_under, 4),
            "fair_over": round(fair_over, 4),
            "fair_under": round(fair_under, 4),
        },
        "edge": {
            "side": side,
            "edge_pct": round(edge_pct, 2),
            "kelly_pct": round(edge.kelly_fraction * 100, 2) if edge else 0.0,
            "ev_per_dollar": round(edge.ev_per_dollar, 4) if edge else 0.0,
            "recommended_stake_pct": round(edge.recommended_stake_pct, 2) if edge else 0.0,
        },
        "classification": classify_prop_state(edge_pct, sim.p_over, side, player_state.fouls, score_diff),
    }


def build_nba_halftime_board(snapshot: dict[str, Any], lines: dict[str, Any] | None = None) -> dict[str, Any]:
    players_raw = snapshot.get("players", [])
    players = [HalftimePlayerStat(**p) for p in players_raw]
    first_half_total_points = int(snapshot.get("home_score", 0)) + int(snapshot.get("away_score", 0))
    score_diff = int(snapshot.get("home_score", 0)) - int(snapshot.get("away_score", 0))

    line_map: dict[tuple[str, str], dict[str, Any]] = {}
    if lines:
        for item in lines.get("lines", []):
            player = item.get("player")
            market = item.get("market")
            if player and market:
                line_map[(player, market)] = item

    results: list[dict[str, Any]] = []
    for player in players:
        for stat in DEFAULT_MARKETS:
            item = line_map.get((player.player, stat))
            if not item:
                # fallback synthetic lines near player's own average so the dashboard still works
                pdata = NBA_PLAYERS.get(player.player)
                if not pdata:
                    continue
                if stat == "pra":
                    line = round(pdata["points"][0] + pdata["rebounds"][0] + pdata["assists"][0] - 0.5, 1)
                elif stat not in pdata:
                    continue
                else:
                    line = round(pdata[stat][0] - 0.5, 1)
                item = {"player": player.player, "market": stat, "line": line, "over_odds": -115, "under_odds": -115, "book": "synthetic"}
            try:
                result = simulate_nba_halftime_prop(
                    player_state=player,
                    line=float(item["line"]),
                    over_odds=int(item.get("over_odds", -115)),
                    under_odds=int(item.get("under_odds", -115)),
                    stat=stat,
                    first_half_total_points=first_half_total_points,
                    score_diff=score_diff if player.team == snapshot.get("home_team") else -score_diff,
                    trials=int(snapshot.get("trials", 2500)),
                )
                result["book"] = item.get("book", "bet365")
                results.append(result)
            except KeyError:
                continue

    results.sort(key=lambda x: x["edge"]["edge_pct"], reverse=True)
    return {
        "game_id": snapshot.get("game_id"),
        "sport": "nba",
        "phase": "halftime",
        "home_team": snapshot.get("home_team"),
        "away_team": snapshot.get("away_team"),
        "home_score": snapshot.get("home_score"),
        "away_score": snapshot.get("away_score"),
        "clock": snapshot.get("clock", "HALF"),
        "board": results,
    }
