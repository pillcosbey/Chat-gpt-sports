from __future__ import annotations

from pydantic import BaseModel, Field


class NbaHalftimePlayerIn(BaseModel):
    player: str
    team: str
    opponent: str
    minutes: float = Field(ge=0, le=48)
    fouls: int = Field(default=0, ge=0, le=6)
    points: int = Field(default=0, ge=0)
    rebounds: int = Field(default=0, ge=0)
    assists: int = Field(default=0, ge=0)
    threes_made: int = Field(default=0, ge=0)
    steals: int = Field(default=0, ge=0)
    blocks: int = Field(default=0, ge=0)
    turnovers: int = Field(default=0, ge=0)
    starters_role: str = "rotation"


class NbaHalftimeImport(BaseModel):
    game_id: str
    home_team: str
    away_team: str
    home_score: int = Field(ge=0)
    away_score: int = Field(ge=0)
    clock: str = "HALF"
    trials: int = Field(default=2500, ge=500, le=10000)
    players: list[NbaHalftimePlayerIn]


class BookLineIn(BaseModel):
    player: str
    market: str
    line: float
    over_odds: int
    under_odds: int
    book: str = "bet365"


class BookLinesImport(BaseModel):
    sport: str
    game_id: str
    lines: list[BookLineIn]
