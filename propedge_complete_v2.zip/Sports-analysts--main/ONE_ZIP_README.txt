PROPEDGE / BUCKETSTOBUCKS ALL-IN-ONE UPGRADE

What is included:
- Main board with clickable player cards
- Deep research page for player analysis
- Player directory page
- NBA teams directory
- MLB teams directory
- API endpoints for teams, players, and research payloads
- Frontend files for directory and research views

Important note:
- This package includes the full upgraded codebase in one zip.
- NBA and MLB team coverage is included in the directory structure.
- Full player coverage depends on your live API/provider data. The local bundled sample repo still contains only a limited built-in player dataset, but the app structure is now set up for deeper clickable research pages and team/player navigation.

Main routes:
- /
- /directory
- /research?player=NAME&sport=nba
- /research?player=NAME&sport=mlb

Main API routes:
- /api/board
- /api/search
- /api/teams
- /api/players
- /api/player/{player_name}/research

How to deploy:
1. Unzip this package.
2. Push contents to your GitHub repo.
3. In Railway, redeploy from the updated repo.
4. Add your live data/API variables in Railway Variables.

Recommended next upgrade:
- Connect your real live roster/player feed so every NBA and MLB player can populate dynamically instead of relying on bundled local samples.
