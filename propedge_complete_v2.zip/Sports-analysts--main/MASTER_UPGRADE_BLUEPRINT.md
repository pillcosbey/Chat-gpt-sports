# PropEdge / BucketsToBuckets Master Upgrade Blueprint

This repo now includes three layers:

1. **Pregame board** for research and discovery.
2. **Deep player pages** for matchup context.
3. **Halftime engine** for live NBA player simulation and live-edge ranking.

## What is already implemented in this zip

- Main board with clickable player cards
- Research page scaffold for deeper player views
- Team / player directory pages
- All NBA teams and all MLB teams listed in navigation data
- Player directories from the repo's built-in player datasets
- New `/halftime` dashboard for importing halftime snapshots and Bet365-style lines
- New live endpoints:
  - `POST /api/live/import/nba-halftime`
  - `POST /api/live/import/book-lines`
  - `GET /api/live/import/status`
  - `GET /api/live/nba/halftime-board?game_id=...`
  - `GET /api/live/nba/watchlist`

## What is not honestly completed yet

These parts require a live source you control, and are scaffolded rather than fully wired:

- direct Bet365 ingestion
- all live NBA box-score player stats from a premium data source
- MLB in-game simulation board tied to official live props
- true playoff-only filtering from a standings/schedule provider
- automatic AI explanation layer using your production model key
- persistent historical snapshot storage in a database

## Best next production steps

### 1. Replace in-memory store with Redis/Postgres
Right now imported halftime snapshots live in memory. That is fine for proof-of-concept, but production should write:
- game id
- timestamp
- player snapshot
- live line snapshot
- model outputs
- final results

### 2. Add your real live player stat feed
The halftime engine is built to accept imported JSON. Connect your real provider to emit one JSON payload per game at halftime.

### 3. Add Bet365 line import worker
Bet365 does not provide a simple public developer feed. In practice, you will need one of these:
- a licensed odds vendor that includes Bet365 where permitted
- your own legally compliant capture pipeline
- a manual import/admin tool

### 4. Add playoff mode flag
At ingestion time, stamp each game with:
- season_type: regular / playoffs
- round
- elimination_game boolean

Then adjust minute projections upward for stars and downward for fringe bench players.

### 5. Add AI explanation route
The model should never do raw calculations first. The API should send the already-ranked top edges to the model only after the simulation layer is done.

## Suggested JSON shape for live halftime import

```json
{
  "game_id": "2026-05-02-tor-cle",
  "home_team": "CLE",
  "away_team": "TOR",
  "home_score": 54,
  "away_score": 49,
  "clock": "HALF",
  "trials": 3000,
  "players": [
    {
      "player": "Donovan Mitchell",
      "team": "CLE",
      "opponent": "TOR",
      "minutes": 18,
      "fouls": 1,
      "points": 17,
      "rebounds": 3,
      "assists": 4,
      "threes_made": 2,
      "steals": 1,
      "blocks": 0,
      "turnovers": 2,
      "starters_role": "star"
    }
  ]
}
```

## Suggested JSON shape for book lines import

```json
{
  "sport": "nba",
  "game_id": "2026-05-02-tor-cle",
  "lines": [
    {
      "player": "Donovan Mitchell",
      "market": "points",
      "line": 29.5,
      "over_odds": -120,
      "under_odds": -110,
      "book": "bet365"
    }
  ]
}
```

## Best roadmap from here

1. wire your actual live player feed into `POST /api/live/import/nba-halftime`
2. wire your actual book line feed into `POST /api/live/import/book-lines`
3. rank the halftime watchlist every 15 to 30 seconds
4. save all snapshots to a database
5. build the AI explanation endpoint over the ranked board
6. add MLB live board using the same pattern
7. backtest halftime scenarios versus closes and finals
