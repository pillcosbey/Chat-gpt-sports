# Live Data Next Steps

## Highest value upgrades

### A. NBA halftime engine
Complete this first.

Needs:
- live player minutes
- fouls
- score margin
- current player box score
- live player props / prices

Outputs:
- projected final stat
- over probability
- under probability
- edge percentage
- classification tag

### B. Playoff-only mode
Your real target is playoff live betting, so add:
- playoff game filter
- tighter minute multipliers for stars
- lower blowout bench assumptions for close playoff games
- coach rotation profiles

### C. Bet365 tracking
Store every update with:
- timestamp
- line
- price
- game clock
- player current stat
- model projected final

That gives you the raw material for later backtests.

### D. AI layer
Once the board is ranked, the AI should answer:
- best 5 halftime edges
- strongest under reactions
- stale lines
- player most likely to clear from here
- best same-game pairings

## Recommended stack

- ingestion worker -> Python or Node
- cache -> Redis
- historical store -> Postgres
- API -> FastAPI
- web -> current static UI or React/Next later
- AI -> server-side model route only
